# AI SOC Command: real server-side login

This puts a **real login** in front of the AI SOC Command website. The published artifact page cannot do this by itself (its login is only a browser demo). Host this small Node server instead.

## What it does
- Passwords are stored as **bcrypt hashes** (never in plain text, never in the page).
- Login sets an **httpOnly, SameSite=Strict, Secure (in production)** cookie holding a signed token that expires after 30 minutes.
- The site (`/app`) is only served to signed-in users. Everyone else is redirected to `/login`.
- **Rate limit**: 8 login attempts per IP per 15 minutes. Wrong usernames and wrong passwords take the same time.
- Roles: `admin` and `analyst`. `/api/audit` (server login audit log) is admin only.
- Security headers via Helmet, with a Content-Security-Policy.

## Run it locally
1. Install Node 18 or newer, then in this folder: `npm install`
2. Make password hashes (use long, unique passwords):
   `npm run hash -- "your-long-admin-password"`
   `npm run hash -- "your-long-analyst-password"`
3. Copy `.env.example` to `.env` and fill in:
   - `JWT_SECRET`: run `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`
   - `USERS`: paste your hashes (keep it on one line)
4. Build the protected page from the site file:
   `node build-app.js path/to/soc_future.html`
5. `npm start`, then open http://localhost:3000

## Put it online
Use any Node host (Render, Railway, Fly.io, a VPS). Set the same variables as environment variables, set `NODE_ENV=production`, and make sure it is served over **HTTPS** (hosts do this for you). Do not commit `.env`.

## Honest limits
- The rate limiter and audit log are **in memory**: fine for one small instance, not for several servers. Use a shared store (for example Redis) and a database for real deployments.
- No password reset, no MFA, no account lockout beyond the rate limit. Add MFA (TOTP) before using this for anything sensitive.
- The site's own "Admin login" button (demo accounts) still exists inside the page. Remove it from the page if you do not want a second, fake login visible.
- The live Claude analyst and shared room only work inside Claude's artifact viewer. On your own server those sections hide themselves.
- Review and test before trusting it with real data. This is a solid starting point, not a security audit.

---
## Deploy to Microsoft Azure (App Service, Linux)
See the chat instructions. Short version: create a Linux Web App with Node 20 LTS, add the app settings
`NODE_ENV=production`, `JWT_SECRET`, `USERS`, `SESSION_MINUTES`, turn on HTTPS Only, then zip-deploy this archive
(`package.json` must be at the zip root, as in this file). Azure runs `npm install` and `npm start` for you.
