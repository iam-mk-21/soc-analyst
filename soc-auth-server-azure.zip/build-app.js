'use strict';
// Wraps the site fragment (the file published as the artifact) into private/app.html,
// adds a small signed-in bar, and keeps it behind the server-side login.
const fs = require('fs');
const src = process.argv[2];
if (!src) { console.error('Usage: node build-app.js path/to/soc_future.html'); process.exit(1); }
const body = fs.readFileSync(src, 'utf8');
const bar = `
<div id="srvbar" style="position:fixed;left:12px;bottom:12px;z-index:100;font:12px ui-monospace,Menlo,monospace;background:rgba(10,20,38,.92);color:#E4F3FF;border:1px solid rgba(80,210,255,.35);border-radius:6px;padding:6px 10px;display:flex;gap:10px;align-items:center">
  <span id="srvwho">server session…</span><button id="srvout" type="button" style="font:inherit;background:transparent;color:#FF7B9B;border:1px solid #FF7B9B;border-radius:4px;padding:2px 8px;cursor:pointer">Sign out</button>
</div>
<script>
fetch('/api/me',{credentials:'same-origin'}).then(function(r){return r.ok?r.json():null}).then(function(j){
  if(!j){location.href='/login';return}
  document.getElementById('srvwho').textContent='Signed in: '+j.user+' ('+j.role+')';
});
document.getElementById('srvout').addEventListener('click',function(){
  fetch('/api/logout',{method:'POST',headers:{'Content-Type':'application/json','X-Requested-With':'fetch'},credentials:'same-origin',body:'{}'}).then(function(){location.href='/login'});
});
</script>`;
const html = '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"></head><body>' + body + bar + '</body></html>';
fs.mkdirSync('private', { recursive: true });
fs.writeFileSync('private/app.html', html);
console.log('Wrote private/app.html (' + html.length + ' bytes)');
