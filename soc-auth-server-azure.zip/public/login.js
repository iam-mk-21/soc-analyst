(function () {
  var f = document.getElementById('f'), msg = document.getElementById('msg'), b = document.getElementById('b');
  f.addEventListener('submit', function (e) {
    e.preventDefault();
    b.disabled = true; msg.textContent = '';
    fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
      credentials: 'same-origin',
      body: JSON.stringify({ username: document.getElementById('u').value, password: document.getElementById('p').value })
    }).then(function (r) {
      return r.json().then(function (j) { return { ok: r.ok, j: j }; });
    }).then(function (x) {
      if (x.ok) { location.href = '/app'; }
      else { msg.textContent = x.j.error || 'Sign-in failed'; b.disabled = false; document.getElementById('p').value = ''; }
    }).catch(function () { msg.textContent = 'Network error. Try again.'; b.disabled = false; });
  });
})();
