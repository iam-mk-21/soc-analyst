'use strict';
require('dotenv').config();
const path = require('path');
const fs = require('fs');
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const PROD = process.env.NODE_ENV === 'production';
const PORT = Number(process.env.PORT || 3000);
const SECRET = process.env.JWT_SECRET || '';
if (SECRET.length < 32) {
  console.error('JWT_SECRET must be set and at least 32 characters. See .env.example');
  process.exit(1);
}
let USERS = [];
try { USERS = JSON.parse(process.env.USERS || '[]'); } catch (e) { /* handled below */ }
if (!Array.isArray(USERS) || USERS.length === 0) {
  console.error('USERS must be a JSON array like [{"u":"admin","h":"<bcrypt hash>","r":"admin"}]. See README.md');
  process.exit(1);
}
const SESSION_MIN = Number(process.env.SESSION_MINUTES || 30);
// Compared against when the username does not exist, so timing does not reveal valid usernames.
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', 12);

const auditLog = []; // in memory; use a database or log service in production
function audit(event, detail) {
  const row = { t: new Date().toISOString(), event, ...detail };
  auditLog.push(row);
  if (auditLog.length > 500) auditLog.shift();
  console.log(JSON.stringify(row));
}

const app = express();
app.disable('x-powered-by');
if (PROD) app.set('trust proxy', 1); // behind a hosting proxy that terminates HTTPS

app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: false,
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],   // the site is a single file with inline script
      styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      fontSrc: ['https://fonts.gstatic.com'],
      imgSrc: ["'self'", 'data:'],
      connectSrc: ["'self'"],
      frameAncestors: ["'none'"],
      baseUri: ["'self'"],
      formAction: ["'self'"],
      objectSrc: ["'none'"]
    }
  },
  referrerPolicy: { policy: 'no-referrer' }
}));
app.use(express.json({ limit: '2kb' }));
app.use(cookieParser());

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 8,                       // 8 attempts per IP per 15 minutes
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many attempts. Try again later.' }
});

function readSession(req) {
  const tok = req.cookies && req.cookies.soc_session;
  if (!tok) return null;
  try { return jwt.verify(tok, SECRET, { algorithms: ['HS256'] }); } catch (e) { return null; }
}
function requireAuth(req, res, next) {
  const s = readSession(req);
  if (!s) {
    if (req.path.startsWith('/api/')) return res.status(401).json({ error: 'Not signed in' });
    return res.redirect('/login');
  }
  req.user = s;
  next();
}
function requireRole(role) {
  return (req, res, next) => (req.user && req.user.r === role) ? next() : res.status(403).json({ error: 'Forbidden' });
}
// Basic CSRF defence for state-changing API calls: JSON body plus a custom header, and SameSite=Strict cookie.
function requireJsonAjax(req, res, next) {
  if (req.get('x-requested-with') !== 'fetch' || !req.is('application/json')) {
    return res.status(400).json({ error: 'Bad request' });
  }
  next();
}

app.post('/api/login', loginLimiter, requireJsonAjax, async (req, res) => {
  const u = typeof req.body.username === 'string' ? req.body.username.trim().toLowerCase().slice(0, 64) : '';
  const p = typeof req.body.password === 'string' ? req.body.password.slice(0, 200) : '';
  const rec = USERS.find(x => x.u === u);
  const ok = await bcrypt.compare(p, rec ? rec.h : DUMMY_HASH);
  if (!rec || !ok) {
    audit('login_failed', { user: u, ip: req.ip });
    return res.status(401).json({ error: 'Wrong username or password' });
  }
  const token = jwt.sign({ u: rec.u, r: rec.r }, SECRET, { algorithm: 'HS256', expiresIn: SESSION_MIN + 'm' });
  res.cookie('soc_session', token, {
    httpOnly: true, sameSite: 'strict', secure: PROD, maxAge: SESSION_MIN * 60 * 1000, path: '/'
  });
  audit('login_ok', { user: rec.u, role: rec.r, ip: req.ip });
  res.json({ ok: true, user: rec.u, role: rec.r });
});

app.post('/api/logout', requireJsonAjax, (req, res) => {
  const s = readSession(req);
  if (s) audit('logout', { user: s.u });
  res.clearCookie('soc_session', { path: '/' });
  res.json({ ok: true });
});

app.get('/api/me', requireAuth, (req, res) => res.json({ user: req.user.u, role: req.user.r, expires: req.user.exp }));
app.get('/api/audit', requireAuth, requireRole('admin'), (req, res) => res.json(auditLog.slice(-100).reverse()));

app.get('/', (req, res) => res.redirect(readSession(req) ? '/app' : '/login'));
app.get('/login', (req, res) => res.sendFile(path.join(__dirname, 'public', 'login.html')));
app.get('/login.js', (req, res) => res.sendFile(path.join(__dirname, 'public', 'login.js')));
app.get('/app', requireAuth, (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.sendFile(path.join(__dirname, 'private', 'app.html'));
});
app.use((req, res) => res.status(404).send('Not found'));

app.listen(PORT, () => console.log(`SOC auth server on http://localhost:${PORT} (${PROD ? 'production' : 'development'})`));
